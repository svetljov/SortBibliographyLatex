﻿namespace SortBibliography
{
    public interface ICitationBuilder
    {
        void BuildOrderedBibliography();
    }
}
